library(testthat)

test_check("ggRandomForests")
